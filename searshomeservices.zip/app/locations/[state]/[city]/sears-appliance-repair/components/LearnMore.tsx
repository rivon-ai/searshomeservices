'use client'

import React from 'react'
import { Link, Refrigerator, WashingMachine, Wind, Flame, Snowflake, Droplet } from 'lucide-react'

export default function LearnMore() {
  return (
    <div className="bg-white">
      {/* Learn More About Our Services */}
      <div className="border-t border-gray-200 pt-8 mb-16">
        <h2 className="text-lg font-bold text-blue-900 mb-8 uppercase tracking-wide">
          Learn More About Our Services
        </h2>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {/* Appliances Column */}
          <div>
            <h3 className="text-sm font-bold text-blue-900 mb-4 uppercase tracking-wide">
              Appliances
            </h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Cooktop</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Double Oven</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Freezer</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Gas Grill</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Microwave</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Range Hood</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Oven</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Trash Compactor</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Washer Dryer Combo</Link></li>
            </ul>
          </div>

          {/* Second Appliances Column */}
          <div>
            <h3 className="text-sm font-bold text-blue-900 mb-4 uppercase tracking-wide opacity-0">
              Appliances
            </h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Dishwasher</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Dryer</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Garbage Disposal</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Ice Maker</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Range</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Refrigerator</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Stacked Laundry</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Washer</Link></li>
            </ul>
          </div>

          {/* Cooling & Heating Column */}
          <div>
            <h3 className="text-sm font-bold text-blue-900 mb-4 uppercase tracking-wide">
              Cooling & Heating
            </h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Boiler</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Furnace</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Gas Furnace</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">HVAC</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Heat Pump</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Humidifier & Dehumidifier</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Water Heater</Link></li>
            </ul>
          </div>

          {/* Fitness & Lawn Column */}
          <div>
            <h3 className="text-sm font-bold text-blue-900 mb-4 uppercase tracking-wide">
              Fitness
            </h3>
            <ul className="space-y-2 mb-6">
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Elliptical Machine</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Stationary Bike</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Stepper</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Treadmill</Link></li>
            </ul>
          </div>
          <div>

            <h3 className="text-sm font-bold text-blue-900 mb-4 uppercase tracking-wide">
              Lawn & Garden
            </h3>
            <ul className="space-y-2">
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Riding Mower</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Snowblower</Link></li>
              <li><Link href="#" className="text-blue-600 hover:underline text-xs">Wide-Deck Lawn Mower</Link></li>
            </ul>
          </div>
        </div>
      </div>

      {/* Sears Appliance Repair Services */}
      <div className="border-t border-gray-200 pt-12">
        <h2 className="text-base font-bold text-blue-900 mb-8 uppercase tracking-wide">
          Sears Appliance Repair Services Near You -- We Repair All Major Appliances
        </h2>

        {/* Top Row of Appliances */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-8">
          {/* Refrigerator */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <Refrigerator className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Refrigerator
            </h3>
          </div>

          {/* Washer */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <WashingMachine className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Washer
            </h3>
          </div>

          {/* Dryer */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <Wind className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Dryer
            </h3>
          </div>

          {/* Dishwasher */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <svg className="w-12 h-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <rect x="4" y="3" width="16" height="18" rx="1" />
                <line x1="4" y1="8" x2="20" y2="8" />
                <circle cx="7" cy="5.5" r="0.5" fill="currentColor" />
                <circle cx="9" cy="5.5" r="0.5" fill="currentColor" />
                <circle cx="11" cy="5.5" r="0.5" fill="currentColor" />
              </svg>
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Dishwasher
            </h3>
          </div>

          {/* Range */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <svg className="w-12 h-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <rect x="4" y="4" width="16" height="16" rx="1" />
                <circle cx="8" cy="9" r="1.5" />
                <circle cx="16" cy="9" r="1.5" />
                <circle cx="8" cy="15" r="1.5" />
                <circle cx="16" cy="15" r="1.5" />
              </svg>
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Range
            </h3>
          </div>
        </div>

        {/* Bottom Row of Appliances */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-8">
          {/* Oven */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <svg className="w-12 h-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <rect x="5" y="6" width="14" height="12" rx="1" />
                <line x1="5" y1="10" x2="19" y2="10" />
                <circle cx="8" cy="8" r="0.5" fill="currentColor" />
                <circle cx="11" cy="8" r="0.5" fill="currentColor" />
                <circle cx="14" cy="8" r="0.5" fill="currentColor" />
              </svg>
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Oven
            </h3>
          </div>

          {/* HVAC */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <Flame className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              HVAC
            </h3>
          </div>

          {/* Freezer */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <Snowflake className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Freezer
            </h3>
          </div>

          {/* Water Heater */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <Droplet className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Water Heater
            </h3>
          </div>

          {/* Cooktop */}
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 flex items-center justify-center mb-3">
              <svg className="w-12 h-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <rect x="4" y="8" width="16" height="10" rx="1" />
                <circle cx="8" cy="11" r="1" />
                <circle cx="16" cy="11" r="1" />
                <circle cx="8" cy="15" r="1" />
                <circle cx="16" cy="15" r="1" />
              </svg>
            </div>
            <h3 className="text-xs font-bold text-gray-900 uppercase tracking-wide">
              Cooktop
            </h3>
          </div>
        </div>

        {/* Schedule Link */}
        <div className="mt-8">
          <Link href="#" className="text-blue-600 hover:underline text-sm">
            Schedule all other repairs
          </Link>
        </div>
      </div>
    </div>
  )
}