'use client'

import { Calendar, FileCheck, Link, Wrench } from 'lucide-react'
import { useParams } from 'next/navigation';
import React from 'react'
import { MdStars } from 'react-icons/md'

interface LocationsProps {
    locations: {
        name: string;
        address: string;
        isTopLocation?: boolean;
    }[];
}

export default function Locations({ locations }: LocationsProps) {
    const params = useParams()
    return (
        <>
            {locations &&
                <div className="border-b pb-20 pt-48 bg-white">
                    {/* Header */}
                    <h2 className="text-2xl font-bold text-blue-900 mb-8 uppercase tracking-wide">
                        LOCATIONS
                    </h2>

                    {/* Locations Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {locations.map((location, index) => (
                            <Link
                                key={index}
                                className="border border-gray-300 rounded-lg p-6 hover:shadow-[0_0_10px_rgba(0,0,0,0.25)] transition-shadow duration-300 bg-white relative"
                                href={`/locations/${params.state}/${params.city}/sears-appliance-repair/${location.address.toLowerCase().replace(/,/g, "").replace(/\s+/g, "-").replace(/--+/g, "-").replace(/^-+|-+$/g, "")}`}
                            >
                                {/* Top Location Badge */}
                                {location.isTopLocation && (
                                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                                        <div className="bg-white flex items-center gap-2 text-blue-950 font-semibold w-fit border border-gray-300 px-4 py-2 rounded-md">
                                            <MdStars />
                                            <span className="text-sm">
                                                Top Location
                                            </span>
                                        </div>
                                    </div>
                                )}

                                {/* Location Name */}
                                <h3 className="text-lg font-bold text-blue-900 mb-3 mt-2 hover:text-blue-700 cursor-pointer flex flex-col gap-1">
                                    <span>{params.city ? ` ${params.city.toString().toUpperCase()}` : ''}</span>
                                    <span className="text-sm">{location.name}</span>
                                </h3>

                                {/* Address */}
                                <p className="text-sm text-gray-600 leading-relaxed">
                                    {location.address}
                                </p>
                            </Link>
                        ))}
                    </div>
                    <div className="py-20 bg-white">
                        <h2 className="text-xl font-bold text-blue-900 mb-6 uppercase tracking-wide">
                            APPLIANCE REPAIR YOU CAN COUNT ON IN FORESTDALE, {params.state}
                        </h2>

                        <div className="space-y-4 text-gray-700 text-sm leading-relaxed mb-8">
                            <p>
                                When a home appliance breaks down, quick action matters. At Sears Home Services, we deliver dependable{' '}
                                <Link href="#" className="text-blue-600 hover:underline">
                                    appliance repair
                                </Link>{' '}
                                throughout Forestdale, {params.state}. Whether it's a malfunctioning oven, a leaking washer, or a fridge that's lost its chill — we're here to help with fast, expert service.
                            </p>

                            <p>
                                With a focus on quality, convenience, and customer care, our local team brings{' '}
                                <Link href="#" className="text-blue-600 hover:underline">
                                    appliance repair services
                                </Link>{' '}
                                directly to your door — no guesswork, no hassle.
                            </p>
                        </div>

                        <div className="mb-8">
                            <h3 className="text-lg font-bold text-blue-900 mb-4">
                                What We Repair in Forestdale
                            </h3>

                            <p className="text-gray-700 text-sm leading-relaxed mb-4">
                                Our technicians are trained to resolve a wide range of appliance problems. From performance issues to part replacements, we're equipped for both standard and specialty repairs, including:
                            </p>

                            <ul className="space-y-2 ml-6">
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    <span className="font-semibold">Refrigerator repair:</span> Cooling failures, ice maker issues, and broken seals
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    <span className="font-semibold">Dishwasher repair:</span> Water drainage, leaks, and poor cleaning cycles
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    <span className="font-semibold">Washing machine & dryer repair:</span> Drum problems, spinning failures, and temperature faults
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    <span className="font-semibold">Range, oven & cooktop repair:</span> Burners not lighting, uneven heating, or control panel errors
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    <span className="font-semibold">HVAC & furnace service:</span>{' '}
                                    <Link href="#" className="text-blue-600 hover:underline">
                                        Inconsistent airflow
                                    </Link>
                                    , thermostat issues, and ignition failures;
                                </li>
                            </ul>

                            <p className="text-gray-700 text-sm leading-relaxed mt-3 ml-6">
                                We work on all major appliance brands, including GE, Samsung, Whirlpool, LG, KitchenAid, Frigidaire, Kenmore, and others — plus high-performance models like Bosch, Electrolux, and Jenn-Air.
                            </p>
                        </div>

                        <div className="mb-8">
                            <h3 className="text-lg font-bold text-blue-900 mb-4">
                                Why Sears is the Right Choice for Appliance Repair
                            </h3>

                            <p className="text-gray-700 text-sm leading-relaxed mb-4">
                                Unlike generic appliance repair services, we deliver a tailored experience backed by:
                            </p>

                            <ul className="space-y-2 ml-6">
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    Skilled, certified technicians
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    Clear, upfront estimates with no surprise fees
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    Same-day or next-day appointment availability in many cases
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    Nationally trusted service, delivered locally
                                </li>
                                <li className="text-gray-700 text-sm leading-relaxed">
                                    Work covered by warranty and our Satisfaction Guarantee
                                </li>
                            </ul>

                            <p className="text-gray-700 text-sm leading-relaxed mt-4">
                                Our goal? To restore your appliances efficiently and affordably — the first time.
                            </p>
                        </div>
                    </div>

                    <div className=" bg-white">
                        {/* How It Works Header */}
                        <div className="mb-8">
                            <h2 className="text-2xl font-bold text-blue-900 mb-6">
                                How It Works: Our Simple 3-Step Process
                            </h2>

                            {/* Step 1 */}
                            <div className="mb-6">
                                <h3 className="text-lg font-bold text-blue-900 mb-2">
                                    1. Schedule Service
                                </h3>
                                <p className="text-gray-600 text-sm leading-relaxed">
                                    Book online or call — flexible time slots and local availability make it easy to get started.
                                </p>
                            </div>

                            {/* Step 2 */}
                            <div className="mb-6">
                                <h3 className="text-lg font-bold text-blue-900 mb-2">
                                    2. Get a Diagnosis
                                </h3>
                                <p className="text-gray-600 text-sm leading-relaxed">
                                    A technician will arrive at your home, inspect the issue, and explain exactly what is needed.
                                </p>
                            </div>

                            {/* Step 3 */}
                            <div className="mb-6">
                                <h3 className="text-lg font-bold text-blue-900 mb-2">
                                    3. Complete the Repair
                                </h3>
                                <p className="text-gray-600 text-sm leading-relaxed">
                                    We'll get your appliance back up and running using high-quality replacement parts — quickly and reliably.
                                </p>
                            </div>
                        </div>

                        {/* Testimonial */}
                        <div className="mb-10">
                            <h3 className="text-lg font-bold text-blue-900 mb-3">
                                A Word from Our Local Sears Home Services Technician
                            </h3>
                            <p className="text-gray-600 text-sm leading-relaxed">
                                As a technician with over 15 years of experience right here in Forestdale, {params.state}, I've come to truly appreciate the value of reliable and efficient home services. There's nothing quite like the satisfaction of fixing a stubborn appliance and seeing the relief on a customer's face. Our community deserves quality services, and that's what we strive to deliver every day. Whether it's a finicky fridge or a worn-out washer, we're here to put things back on track. If you're searching for <span className="font-semibold">home appliance repair near me</span>, look no further than our dedicated team at Sears Home Services. We understand the unique needs of our Forestdale neighbors and are committed to providing top-notch service with a personal touch.
                            </p>
                        </div>

                        {/* Main Title */}
                        <div className="mb-8">
                            <h2 className="text-2xl font-bold text-blue-900 mb-4">
                                Schedule Appliance Repair in Forestdale, {params.state}
                            </h2>
                            <p className="text-gray-600 text-sm leading-relaxed mb-4">
                                Don't let a malfunctioning appliance disrupt your home life. Choose Sears Appliance Repair in Forestdale for dependable, local service — whether you're in the city center, uptown, or suburban neighborhoods — we're nearby and ready to help.
                            </p>
                            <p className="text-gray-600 text-sm leading-relaxed">
                                <a href="#" className="text-blue-600 hover:underline">Book your appliance repair now</a> or call us at <span className="font-semibold">1-802-613-1926</span> to speak with a representative. We're often available the same day in neighborhoods across Forestdale.
                            </p>
                        </div>

                        {/* How It Works Section */}
                        <div className="border-t border-gray-200 pt-10">
                            <h2 className="text-xl font-bold text-blue-900 mb-8 uppercase tracking-wide">
                                How It Works
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                {/* Easy Scheduling */}
                                <div className="text-center">
                                    <div className="flex justify-center mb-4">
                                        <div className="w-16 h-16 flex items-center justify-center">
                                            <Calendar className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
                                        </div>
                                    </div>
                                    <h3 className="text-sm font-bold text-blue-900 mb-3 uppercase tracking-wide">
                                        Easy Scheduling
                                    </h3>
                                    <p className="text-gray-600 text-sm leading-relaxed">
                                        Book online in less than a minute.
                                    </p>
                                </div>

                                {/* Diagnostic Fee */}
                                <div className="text-center">
                                    <div className="flex justify-center mb-4">
                                        <div className="w-16 h-16 flex items-center justify-center">
                                            <Wrench className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
                                        </div>
                                    </div>
                                    <h3 className="text-sm font-bold text-blue-900 mb-3 uppercase tracking-wide">
                                        Diagnostic Fee
                                    </h3>
                                    <p className="text-gray-600 text-sm leading-relaxed">
                                        Apply your diagnostic fee to the costs of repair.
                                    </p>
                                </div>

                                {/* Expert Technicians */}
                                <div className="text-center">
                                    <div className="flex justify-center mb-4">
                                        <div className="w-16 h-16 flex items-center justify-center">
                                            <FileCheck className="w-12 h-12 text-blue-600" strokeWidth={1.5} />
                                        </div>
                                    </div>
                                    <h3 className="text-sm font-bold text-blue-900 mb-3 uppercase tracking-wide">
                                        Expert Technicians
                                    </h3>
                                    <p className="text-gray-600 text-sm leading-relaxed">
                                        Save up to $150 on your repair if you enroll in a home warranty.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            }
        </>
    )
}