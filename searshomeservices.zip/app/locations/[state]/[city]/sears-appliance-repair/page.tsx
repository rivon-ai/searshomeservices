
import React from 'react'
import Link from 'next/link'
import img from '@/public/alabamaImage.webp'
import { Calendar, Wrench, FileCheck, Star, User } from 'lucide-react';
import Locations from './components/Locations'
import RatingSection from './components/RatingSection'
import LearnMore from './components/LearnMore'
import ImageSection from './components/ImageSection'


const resources = [
    {
        image: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?w=400&h=300&fit=crop",
        title: "Deciphering Samsung Clothes Dryer Error Codes",
        readTime: "5 min read",
        difficulty: "Dec 09",
        description: "Find the most common Samsung clothes dryer error codes and their solutions. Get professional help...",
        category: "Dryer"
    },
    {
        image: "https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=400&h=300&fit=crop",
        title: "Troubleshooting Garage Door Opener Power Issues",
        readTime: "3 min read",
        difficulty: "Dec 09",
        description: "Sears Home Services specializes in troubleshooting power issues in garage door openers. Get the help...",
        category: "Garage Door Opener"
    },
    {
        image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=400&h=300&fit=crop",
        title: "How Can I Prepare for Rolling Blackouts?",
        readTime: "9 min read",
        difficulty: "Dec 09",
        description: "Prepare for rolling blackouts with these expert tips from Sears Home Services.",
        category: "Generator"
    },
    {
        image: "https://images.unsplash.com/photo-1600121848594-d8644e57abab?w=400&h=300&fit=crop",
        title: "8 Steps to Install a Wood Fence",
        readTime: "13 min read",
        difficulty: "Dec 09",
        description: "Get expert advice and learn about the 8 steps you need to follow to install a wood fence.",
        category: "Fencing"
    }
];

const reviews = [
    {
        title: "Top Notch Service",
        rating: 5,
        text: "Cesar was very thorough and professional in dealing with the plumbing issue with our Refrigerator. My wife and I were very satisfied with his work.",
        author: "MARK A. OOLTEWAH, TN"
    },
    {
        title: "Excellent!",
        rating: 5,
        text: "Clayton was very friendly, professional and thorough! He took care of my problem in no time and let us know what to expect. I really appreciate his work and his demeanor. Thanks so...",
        author: "NANCY M. PALMYRA, MO"
    },
    {
        title: "VERY PROFESSIONAL, AND KNO...",
        rating: 5,
        text: "WE FOUND OUT THAT IT WAS CHEAPER TO BUY A NEW REFRIDGERATOR, THAN TO GET THIS ONE FIXED, OUTSIDE OF THAT MR. JEFF WAS VERY COURTUS....",
        author: "PAMELA B. PASADENA, MD"
    }
];

const glossaryTerms = [
    {
        title: "What is the drum of the washing machine?",
        description: "The drum is the core part of the washer that holds your laundry and enables the cleaning process...."
    },
    {
        title: "What is a 608 Certification?",
        description: "The 608 Certification, regulated by the Environmental Protection Agency (EPA), is required for HVA..."
    },
    {
        title: "What is a Compressor?",
        description: "A compressor is a mechanical device that increases the pressure of a gas by reducing its volume...."
    },
    {
        title: "What is a Condenser?",
        description: "A condenser is a component of HVAC and refrigeration systems, responsible for releasing absorbed..."
    }
];

const symptoms = [
    {
        title: "Payne central air not working",
        description: "When your Payne central air conditioner won't turn on or isn't cooling, check for power problem..."
    },
    {
        title: "ICP central air not working",
        description: "When your ICP central air conditioner won't turn on or isn't cooling, check for power problem..."
    },
    {
        title: "Heil central air not working",
        description: "When your Heil central air conditioner won't turn on or isn't cooling, check for power problem..."
    },
    {
        title: "Carrier central air not working",
        description: "When your Carrier central air conditioner won't turn on or isn't cooling, check for power problem..."
    },
    {
        title: "Comfortmaker central air not working",
        description: "When your Comfortmaker central air conditioner won't turn on or isn't cooling, check for power..."
    },
    {
        title: "Ruud central air not working",
        description: "When your Ruud central air conditioner won't turn on or isn't cooling, check for power problem..."
    }
];

const locations = [
    {
        name: "Sears Appliance Repair",
        address: "1000 E 41st, Austin, Texas 78751",
        isTopLocation: true
    },
    {
        name: "Sears Appliance Repair",
        address: "2901 S Capitol of Texas Highway, Austin, Texas 78746",
        isTopLocation: false
    },
    {
        name: "Sears Appliance Repair",
        address: "12625 N I-H 35, Austin, Texas 78753",
        isTopLocation: false
    }
]

export default function page() {
    return (
        <div className='w-full xl:w-[75%] mx-auto mt-6'>

            <ImageSection img={img} />

            <Locations locations={locations} />

            {/* Common Repair Services */}
            <div className="py-20 bg-white">
                <div className="mb-16">
                    <h2 className="text-xl font-bold text-gray-900 mb-6">
                        Learn about our most common repair services
                    </h2>
                    <ul className="space-y-2">
                        <li>
                            <Link href="#" className="text-blue-600 hover:underline text-sm">
                                Oven Repair Service
                            </Link>
                        </li>
                        <li>
                            <Link href="#" className="text-blue-600 hover:underline text-sm">
                                Refrigerator Repair Service
                            </Link>
                        </li>
                        <li>
                            <Link href="#" className="text-blue-600 hover:underline text-sm">
                                Dishwasher Repair Service
                            </Link>
                        </li>
                        <li>
                            <Link href="#" className="text-blue-600 hover:underline text-sm">
                                Washing Machine Repair Service
                            </Link>
                        </li>
                        <li>
                            <Link href="#" className="text-blue-600 hover:underline text-sm">
                                Dryer Repair Service
                            </Link>
                        </li>
                    </ul>
                </div>

                {/* Why Sears Home Services */}
                <div className="border-t border-gray-200 pt-12 mb-16">
                    <h2 className="text-xl font-bold text-blue-900 mb-10 uppercase tracking-wide">
                        Why Sears Home Services?
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {/* Happy Customers */}
                        <div className="text-left">
                            <div className="mb-4">
                                <Star className="w-10 h-10 text-yellow-400 fill-yellow-400" strokeWidth={1.5} />
                            </div>
                            <h3 className="text-sm font-bold text-gray-900 mb-3 uppercase tracking-wide">
                                Happy Customers
                            </h3>
                            <p className="text-gray-600 text-xs leading-relaxed">
                                Average of 4,600,000+ homes serviced/year. Over 1,000,000 5 star ratings.
                            </p>
                        </div>

                        {/* Flexible Scheduling */}
                        <div className="text-left">
                            <div className="mb-4">
                                <Calendar className="w-10 h-10 text-blue-600" strokeWidth={1.5} />
                            </div>
                            <h3 className="text-sm font-bold text-gray-900 mb-3 uppercase tracking-wide">
                                Flexible Scheduling
                            </h3>
                            <p className="text-gray-600 text-xs leading-relaxed">
                                Available 6 days a week in most areas.
                            </p>
                        </div>

                        {/* Expert Technicians */}
                        <div className="text-left">
                            <div className="mb-4">
                                <User className="w-10 h-10 text-blue-600" strokeWidth={1.5} />
                            </div>
                            <h3 className="text-sm font-bold text-gray-900 mb-3 uppercase tracking-wide">
                                Expert Technicians
                            </h3>
                            <p className="text-gray-600 text-xs leading-relaxed">
                                2,500+ manufacturer-trained technicians with an average of 10+ years of experience.
                            </p>
                        </div>

                        {/* Quality Parts */}
                        <div className="text-left">
                            <div className="mb-4">
                                <Wrench className="w-10 h-10 text-blue-600" strokeWidth={1.5} />
                            </div>
                            <h3 className="text-sm font-bold text-gray-900 mb-3 uppercase tracking-wide">
                                Quality Parts for Hundreds of Brands
                            </h3>
                            <p className="text-gray-600 text-xs leading-relaxed">
                                Repairs for most major brands, no matter where you bought it.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Brands We Repair */}
                <div className="border-t border-gray-200 pt-12">
                    <h2 className="text-xl font-bold text-gray-900 mb-4 uppercase tracking-wide">
                        Brands We Repair
                    </h2>

                    <p className="text-gray-600 text-sm mb-8">
                        We repair all major brands, no matter where you bought it.
                    </p>

                    {/* Brand Logos - Row 1 */}
                    <div className="flex flex-wrap items-center justify-center gap-12 mb-8">
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-2xl font-serif text-gray-700">Kenmore</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-2xl font-bold text-gray-700">Whirlpool</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl font-bold text-gray-700 tracking-wider">FRIGIDAIRE</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-2xl font-bold text-gray-700">MAYTAG</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-2xl font-serif text-gray-700">GE</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl font-bold text-gray-700">KitchenAid</span>
                        </div>
                    </div>

                    {/* Brand Logos - Row 2 */}
                    <div className="flex flex-wrap items-center justify-center gap-12 mb-8">
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl font-bold text-gray-700 tracking-wider">JENN-AIR</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-2xl font-bold text-gray-700">LG</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl text-gray-700">Electrolux</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl font-bold text-gray-700">BOSCH</span>
                        </div>
                        <div className="grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all">
                            <span className="text-xl font-bold text-gray-700 tracking-wider">SAMSUNG</span>
                        </div>
                    </div>

                    <div className="mt-6">
                        <Link href="#" className="text-blue-600 hover:underline text-sm">
                            See the complete list of brands we repair
                        </Link>
                    </div>
                </div>
            </div>

            <RatingSection reviews={reviews} />

            <LearnMore />

            {/* Repair Resources */}
            <div className="w-[70%] mx-auto py-20">
                {/* Header */}
                <h2 className="text-3xl font-bold text-center text-blue-900 mb-12">
                    Repair Resources
                </h2>

                {/* Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {resources.map((resource, index) => (
                        <div key={index} className="border border-t-0 flex flex-col h-full shadow-lg rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                            {/* Image */}
                            <div className="relative overflow-hidden rounded-t-lg">
                                <img
                                    src={resource.image}
                                    alt={resource.title}
                                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                                />
                            </div>

                            {/* Content */}
                            <div className="bg-white p-6 rounded-b-lg  border-gray-200">
                                <h3 className="text-xl font-semibold text-blue-900 mb-3 hover:text-blue-700 cursor-pointer">
                                    {resource.title}
                                </h3>

                                <div className="flex items-center gap-3 text-sm text-gray-600 mb-3">
                                    <span>{resource.readTime}</span>
                                    <span>•</span>
                                    <span>{resource.difficulty}</span>
                                </div>

                                <p className="text-gray-700 text-sm leading-relaxed mb-4">
                                    {resource.description}
                                </p>

                                <div className="text-sm text-blue-600 font-medium">
                                    {resource.category}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Schedule All Other Repairs Link */}
                <div className="mt-8 text-center">
                    <a
                        href="#"
                        className="text-blue-600 hover:text-blue-800 text-sm font-medium hover:underline"
                    >
                        Schedule all other repairs
                    </a>
                </div>
            </div>

            <div className="max-w-6xl mx-auto px-4 py-12 bg-white">
                {/* Glossary Terms Section */}
                <div className="mb-16">
                    <h2 className="text-2xl font-bold text-blue-900 mb-8">
                        Glossary Terms
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                        {glossaryTerms.map((term, index) => (
                            <div key={index}>
                                <h3 className="text-base font-semibold text-blue-900 mb-2 hover:text-blue-700 cursor-pointer">
                                    {term.title}
                                </h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    {term.description}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Common Appliance Symptoms Section */}
                <div>
                    <h2 className="text-2xl font-bold text-blue-900 mb-8">
                        Common Appliance Symptoms
                    </h2>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                        {symptoms.map((symptom, index) => (
                            <div key={index}>
                                <h3 className="text-base font-semibold text-blue-900 mb-2 hover:text-blue-700 cursor-pointer">
                                    {symptom.title}
                                </h3>
                                <p className="text-sm text-gray-700 leading-relaxed">
                                    {symptom.description}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

        </div>
    )
}